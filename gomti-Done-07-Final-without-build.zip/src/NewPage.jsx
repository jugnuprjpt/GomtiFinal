import React from 'react'

 const NewPage = () => {
  return (
    <>
        abc
        
  </>
  )
}
export default NewPage
