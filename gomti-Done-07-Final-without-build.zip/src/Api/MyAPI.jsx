import chair from "../img/chair.png";
import truck from "../img/truck.png";
import tolly from "../img/tolly.png";
import car from "../img/car.png";

const MyAPI = [
  { id: 1, image: chair, title: "Household Goods" },
  { id: 2, image: truck, title: "Plants and Heavy Equipment" },
  { id: 3, image: tolly, title: "Home or Office Moves" },
  { id: 4, image: car, title: "Vehical,cars, Boat" },
];

export default MyAPI;
