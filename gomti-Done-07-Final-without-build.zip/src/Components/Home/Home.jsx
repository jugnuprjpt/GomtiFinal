import React from 'react'
import Slider from '../Slider/Slider'

 const Home = () => {
  return (
    <>
        <Slider></Slider>
    </>
  )
}
export default Home
