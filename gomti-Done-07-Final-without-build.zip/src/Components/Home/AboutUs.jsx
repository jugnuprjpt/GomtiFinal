import React from 'react'
import About from '../About/About'

const AboutUs = () => {
  return (
    <>
       <About></About>
    </>
  )
}
export default AboutUs
